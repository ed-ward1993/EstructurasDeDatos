package prueba;

import controlador.TipoUsuarioControlador;
import controlador.TipoUsuarioNiniaControlador;

public class Aplicacion {
	
	public static void main(String[] args) {
		TipoUsuarioNiniaControlador controller = new TipoUsuarioNiniaControlador();
		//controller.insertar(28846797, 28844044);
		System.out.println(controller.findAll());
	}
	
	/*
	 * registrar niña: HACER COMPROBACION DE USUARIO (que no sea de otro tipo)
	 * NiniaControlador controller = new NiniaControlador();
	 * controller.insert(1, 28844044, "Ingresada por solicitud de la familia");
	 */
	
	/*
	 * registrar registro salud:
	 * RegistroSaludControlador controller = new RegistroSaludControlador();
	 * controller.insert(28844044, 60, 160, 120, "buenas condiciones de salud");
	 */
	
	/*
	 * registrar tipo de usuario: HACER COMPROBACION DE USUARIO (que no sea niña)
	 * TipoUsuarioControlador controller = new TipoUsuarioControlador();
	 * controller.insert(2001, 1106901603, "familiar");
	 */
	
	/*
	 * registrar tipo usuario relacionado a una niña:
	 * TipoUsuarioNiniaControlador controller = new TipoUsuarioNiniaControlador();
	 * controller.insertar(1106901603, 28844044);
	 */
	
}
