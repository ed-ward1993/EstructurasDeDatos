package mensaje;

import java.io.Serializable;

public class SentenciaSQL implements Serializable{
	
	private String sentencia;
	
	public SentenciaSQL(String sentencia) {
		this.sentencia = sentencia;		
	}
	
	public String getSentencia() {
		return sentencia;
	}
	
	public void setSentecia(String sentecia) {
		this.sentencia = sentecia;
	}

}
