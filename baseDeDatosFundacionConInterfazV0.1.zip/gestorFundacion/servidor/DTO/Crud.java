package DTO;

public interface Crud {
	public String insert();

	public String update();

	public String delete();

	public String findByPk();

	public String findAll();
}
