package controlador;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import DAO.RegistroSaludDAO;
import DTO.RegistroSaludDTO;

public class RegistroSaludControlador {
	
	RegistroSaludDAO dao;
	
	public RegistroSaludControlador() {
		dao = new RegistroSaludDAO();
	}
	
	public boolean insert(long niniaDocumento,
			int peso, double altura, int tension, String descripcionCondicion) {
		RegistroSaludDTO objeto = new RegistroSaludDTO(niniaDocumento, peso, altura, tension, descripcionCondicion);
		return dao.insert(objeto);
	}
	
	public boolean update(long niniaDocumento,
			int peso, double altura, int tension, String descripcionCondicion) {
		RegistroSaludDTO objeto = new RegistroSaludDTO(niniaDocumento, peso, altura, tension, descripcionCondicion);
		return dao.update(objeto);
	}
	
	public boolean delete(long niniaDocumento) {
		RegistroSaludDTO objeto = new RegistroSaludDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.delete(objeto);
	}
	
	public RegistroSaludDTO findByPk(long niniaDocumento) {
		RegistroSaludDTO objeto = new RegistroSaludDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.getByPk(objeto);
	}
	
	public List<RegistroSaludDTO> findAll(){
		RegistroSaludDTO objeto = new RegistroSaludDTO();
		return dao.getFindAll(objeto);
	}

}
