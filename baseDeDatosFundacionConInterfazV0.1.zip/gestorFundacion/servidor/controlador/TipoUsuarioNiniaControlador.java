package controlador;

import java.util.List;

import DAO.TipoUsuarioNiniaDAO;
import DTO.TipoUsuarioNiniaDTO;

public class TipoUsuarioNiniaControlador {
	
	TipoUsuarioNiniaDAO dao = new TipoUsuarioNiniaDAO();
	
	public boolean insertar(int tipoUsuarioCodigo, int niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO(tipoUsuarioCodigo, niniaDocumento);
		return dao.insert(objeto);
	}
	
	public boolean update(int tipoUsuarioCodigo, int niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO(tipoUsuarioCodigo, niniaDocumento);
		return dao.insert(objeto);
	}
	
	public boolean delete(int niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.delete(objeto);
	}
	
	public TipoUsuarioNiniaDTO findByPk(int niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.getByPk(objeto);
	}
	
	public List<TipoUsuarioNiniaDTO> findAll() {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		return dao.getFindAll(objeto);
	}
	
}
