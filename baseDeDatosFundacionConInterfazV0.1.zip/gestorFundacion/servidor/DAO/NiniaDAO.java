package DAO;

import DTO.NiniaDTO;

public class NiniaDAO extends GenericDAO<NiniaDTO>{

	public NiniaDAO() {
		super(NiniaDTO.class);
	}

}
