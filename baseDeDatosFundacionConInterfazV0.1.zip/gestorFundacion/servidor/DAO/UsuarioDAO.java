package DAO;

import DTO.UsuarioDTO;

public class UsuarioDAO extends GenericDAO<UsuarioDTO> {

	public UsuarioDAO() {
		super(UsuarioDTO.class);
	}	
	
}
