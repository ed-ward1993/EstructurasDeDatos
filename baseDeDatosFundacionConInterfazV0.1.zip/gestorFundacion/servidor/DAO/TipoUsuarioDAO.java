package DAO;

import DTO.TipoUsuarioDTO;

public class TipoUsuarioDAO extends GenericDAO<TipoUsuarioDTO> {

	public TipoUsuarioDAO() {
		super(TipoUsuarioDTO.class);
	}	

}
