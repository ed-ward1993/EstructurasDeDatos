package DAO;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.LinkedList;
import java.util.List;

import DTO.Crud;
import conexion.Conexion;

public class GenericDAO<T extends Crud> {
	
	public Conexion con;
	public Class<T> entityClass;
	
	public GenericDAO(Class<T> entityClass) {
		this.entityClass = entityClass;
		this.con = Conexion.getInstance();
	}
	
	public T getByPk(Crud dato){
		ResultSet rs = con.getQuery(dato.findByPk());
		T nuevoObjeto = null;
		try {
			ResultSetMetaData rsMD = rs.getMetaData();
			Method[] metodosDao = entityClass.getMethods();
			nuevoObjeto = (T) entityClass.getDeclaredConstructor().newInstance();
			while(rs.next()) {
				for(int i=1 ; i<=rsMD.getColumnCount() ; i++) {
					Method metodoEjecutar = buscarMetodo(rsMD.getColumnName(i), metodosDao);
					if(metodoEjecutar!=null) {
						metodoEjecutar.invoke(nuevoObjeto, rs.getObject(i));
					}
				}
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return nuevoObjeto;
	}
	
	public  List<T> getFindAll(Crud dato){
		ResultSet rs = con.getQuery(dato.findAll());
		List<T> dates = new LinkedList<T>();
		try {
			ResultSetMetaData rsMD = rs.getMetaData();
			Method[] metodosDao = entityClass.getMethods();
			while(rs.next()) {
				T nuevoObjeto = nuevoObjeto = (T) entityClass.getDeclaredConstructor().newInstance();
				for(int i=1 ; i<=rsMD.getColumnCount() ; i++) {
					Method metodoEjecutar = buscarMetodo(rsMD.getColumnName(i), metodosDao);
					if(metodoEjecutar!=null) {
						Object obj = rs.getObject(i);
						metodoEjecutar.invoke(nuevoObjeto, obj);
					}
				}
				dates.add(nuevoObjeto);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return (List<T>) dates;
	}

	public boolean insert(Crud dato) {
		return con.executeQuery(dato.insert());
	}
	
	public boolean update(Crud dato) {
		return con.executeQuery(dato.update());
	}
	
	public boolean delete(Crud dato) {
		return con.executeQuery(dato.delete());
	}
	
	public Method buscarMetodo(String nombreColumna, Method[] metodos) {
		Method result = null;
		nombreColumna = nombreColumna.replace("_", "");
		for(Method metodo : metodos) {
			if(metodo.getName().equalsIgnoreCase("set"+nombreColumna)) {
				result = metodo;
				break;
			}
		}
		return result;
	}
}



















