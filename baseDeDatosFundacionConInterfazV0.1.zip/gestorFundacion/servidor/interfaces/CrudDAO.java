package interfaces;

import java.util.List;

import DTO.Crud;

public interface CrudDAO {
	public boolean insert(Crud dato);

	public boolean update(Crud dato);

	public boolean delete(Crud dato);

	public Crud findByPk(Crud dato);

	public List<Crud> findAll();	
}
