import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToggleButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLayeredPane;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class SubPrincipal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SubPrincipal frame = new SubPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SubPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(10, 0, 283, 21);
		contentPane.add(menuBar);
		
		JMenu mnArchivo = new JMenu("Archivo");
		menuBar.add(mnArchivo);
		
		JMenuItem mntmSalir = new JMenuItem("Salir");
		mntmSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnArchivo.add(mntmSalir);
		
		JMenu mnUsuario = new JMenu("Usuario");
		menuBar.add(mnUsuario);
		
		JMenu mnRegistrar = new JMenu("Registrar");
		mnUsuario.add(mnRegistrar);
		
		JMenuItem mntmNia_3 = new JMenuItem("Ni\u00F1a");
		mntmNia_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RegistroNiña registrarNiña = new RegistroNiña();
				registrarNiña.setVisible(true);
			}
		});
		mnRegistrar.add(mntmNia_3);
		
		JMenuItem mntmFuncionario = new JMenuItem("Funcionario");
		mntmFuncionario.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RegistrarFuncionario registrarFun = new RegistrarFuncionario();
				registrarFun.setVisible(true);
			}
		});
		mnRegistrar.add(mntmFuncionario);
		
		JMenuItem mntmFamiliar = new JMenuItem("Familiar");
		mntmFamiliar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				RegistroFamiliar registroFam = new RegistroFamiliar();
				registroFam.setVisible(true);
			}
		});
		mnRegistrar.add(mntmFamiliar);
		
		JMenuItem mntmSaludNia = new JMenuItem("Salud Ni\u00F1a");
		mntmSaludNia.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				
				RegistroSalud registroSalud = new RegistroSalud ();
				registroSalud.setVisible(true);
			}
		});
		mnRegistrar.add(mntmSaludNia);
		
		JMenuBar menuBar_1 = new JMenuBar();
		mnRegistrar.add(menuBar_1);
		
		JMenu mnConsultar = new JMenu("Consultar");
		mnUsuario.add(mnConsultar);
		
		JMenuItem mntmNia_1 = new JMenuItem("Ni\u00F1a");
		mntmNia_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ConsultarNiña consultarNiña = new ConsultarNiña();
				consultarNiña.setVisible(true);
			}
		});
		mnConsultar.add(mntmNia_1);
		
		JMenuItem mntmFuncionario_1 = new JMenuItem("Funcionario");
		mnConsultar.add(mntmFuncionario_1);
		
		JMenuItem mntmFamiliar_1 = new JMenuItem("Familiar");
		mnConsultar.add(mntmFamiliar_1);
		
		JMenu mnEliminar = new JMenu("Eliminar");
		mnUsuario.add(mnEliminar);
		
		JMenuItem mntmNia_2 = new JMenuItem("Ni\u00F1a");
		mntmNia_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				EliminarNiña eliminarNiña = new EliminarNiña ();
				eliminarNiña.setVisible(true);
			}
		});
		mnEliminar.add(mntmNia_2);
		
		JMenuItem mntmFuncionario_2 = new JMenuItem("Funcionario");
		mntmFuncionario_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				EliminarFuncionario eliminarFun = new EliminarFuncionario();
				eliminarFun.setVisible(true);
			}
		});
		mnEliminar.add(mntmFuncionario_2);
		
		JMenu mnActualizar = new JMenu("Actualizar");
		mnUsuario.add(mnActualizar);
		
		JMenuItem mntmNia = new JMenuItem("Ni\u00F1a");
		mntmNia.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ActualizarNiña actNiña = new ActualizarNiña();
				actNiña.setVisible(true);
			}
		});
		mnActualizar.add(mntmNia);
		
		JMenuItem mntmFuncionario_3 = new JMenuItem("Funcionario");
		mntmFuncionario_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				ActualizarFuncionario actFun = new ActualizarFuncionario();
				actFun.setVisible(true);
			}
		});
		mnActualizar.add(mntmFuncionario_3);
		
		JMenu mnAyuda = new JMenu("Ayuda");
		menuBar.add(mnAyuda);
		
		JMenu mnAcercaDe = new JMenu("Acerca de...");
		mnAyuda.add(mnAcercaDe);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ximena Ospina\\Pictures\\descarga.jpg"));
		lblNewLabel.setBounds(116, 26, 239, 224);
		contentPane.add(lblNewLabel);
	}
}
