import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class RegistroFamiliar extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroFamiliar frame = new RegistroFamiliar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistroFamiliar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistrarFamiliar = new JLabel("REGISTRAR FAMILIAR");
		lblRegistrarFamiliar.setForeground(Color.RED);
		lblRegistrarFamiliar.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarFamiliar.setBounds(145, 11, 198, 45);
		contentPane.add(lblRegistrarFamiliar);
		
		JLabel label = new JLabel("Documento:");
		label.setBounds(43, 85, 59, 14);
		contentPane.add(label);
		
		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(159, 82, 156, 20);
		contentPane.add(txtDocumento);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(184, 270, 89, 23);
		contentPane.add(btnRegistrar);
		
		JLabel label_1 = new JLabel("Nombres:");
		label_1.setBounds(43, 108, 46, 14);
		contentPane.add(label_1);
		
		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(158, 105, 266, 20);
		contentPane.add(txtNombres);
		
		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setBounds(43, 133, 59, 14);
		contentPane.add(label_2);
		
		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(159, 130, 265, 20);
		contentPane.add(txtApellidos);
		
		JLabel label_3 = new JLabel("Celular:");
		label_3.setBounds(43, 156, 46, 14);
		contentPane.add(label_3);
		
		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(159, 153, 191, 20);
		contentPane.add(txtCelular);
		
		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setBounds(43, 181, 59, 14);
		contentPane.add(label_4);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(159, 178, 265, 20);
		contentPane.add(txtDireccion);
		
		JLabel label_5 = new JLabel("Genero:");
		label_5.setBounds(43, 206, 46, 14);
		contentPane.add(label_5);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"M", "F", "Otro"}));
		comboBox.setBounds(159, 203, 70, 20);
		contentPane.add(comboBox);
	}
}
