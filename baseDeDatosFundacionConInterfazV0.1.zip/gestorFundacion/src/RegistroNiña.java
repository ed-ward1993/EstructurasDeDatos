import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.awt.event.ActionEvent;

public class RegistroNiña extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtId;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JTextField txtDescripcion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroNiña frame = new RegistroNiña();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistroNiña() {
		setTitle("Registrar Ni\u00F1a");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 486, 393);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistrarNia = new JLabel("REGISTRAR NI\u00D1A");
		lblRegistrarNia.setForeground(new Color(255, 0, 0));
		lblRegistrarNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarNia.setBounds(145, 11, 198, 45);
		contentPane.add(lblRegistrarNia);
		
		JLabel lblDocumento = new JLabel("Documento:");
		lblDocumento.setBounds(43, 85, 59, 14);
		contentPane.add(lblDocumento);
		
		JLabel lblId = new JLabel("Id:");
		lblId.setBounds(10, 110, 139, 14);
		contentPane.add(lblId);
		
		JLabel lblNombres = new JLabel("Nombres:");
		lblNombres.setBounds(43, 135, 46, 14);
		contentPane.add(lblNombres);
		
		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setBounds(43, 160, 59, 14);
		contentPane.add(lblApellidos);
		
		JLabel lblDireccin = new JLabel("Direcci\u00F3n:");
		lblDireccin.setBounds(43, 193, 59, 14);
		contentPane.add(lblDireccin);
		
		txtDocumento = new JTextField();
		txtDocumento.setBounds(159, 82, 156, 20);
		contentPane.add(txtDocumento);
		txtDocumento.setColumns(10);
		
		txtId = new JTextField();
		txtId.setBounds(159, 107, 265, 17);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtNombres = new JTextField();
		txtNombres.setBounds(158, 132, 266, 20);
		contentPane.add(txtNombres);
		txtNombres.setColumns(10);
		
		txtApellidos = new JTextField();
		txtApellidos.setBounds(159, 157, 265, 20);
		contentPane.add(txtApellidos);
		txtApellidos.setColumns(10);
		
		txtDireccion = new JTextField();
		txtDireccion.setBounds(159, 190, 265, 20);
		contentPane.add(txtDireccion);
		txtDireccion.setColumns(10);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n:");
		lblDescripcin.setBounds(43, 218, 70, 14);
		contentPane.add(lblDescripcin);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(157, 221, 267, 88);
		contentPane.add(txtDescripcion);
		txtDescripcion.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String mensaje;
				mensaje = "Documento = "+txtDocumento.getText()+"fecha de nacimiento"+txtId.getText()+ "nombres = "+txtNombres.getText()+"Apellidos = "+txtApellidos.getText()+"Direccion= "+txtDireccion.getText()+"Descripcion= "+txtDescripcion.getText();
				
				UsuarioControlador controlUsuario = new UsuarioControlador();
				UsuarioDTO usuario = new UsuarioDTO();
				usuario = controlUsuario.findByPk(Long.parseLong((txtDocumento.getText())));
				if(usuario.getDocumento() == 0){
				controlUsuario.insert(Long.parseLong(txtDocumento.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText(), "ninia1@gmail.com", "3219", "F");
				NiniaControlador controlNinia = new NiniaControlador();
				controlNinia.insert(Integer.parseInt(txtId.getText()), Long.parseLong((txtDocumento.getText())), txtDescripcion.getText());
				txtDescripcion.setText(usuario.getApellidos());
				JOptionPane.showMessageDialog(null, "niña registrada en la base de datos");
				System.out.print(mensaje);
				}else {
					JOptionPane.showMessageDialog(null, "La niña ya existe en la base de datos");
				}
				
			}
		});
		btnRegistrar.setBounds(184, 320, 89, 23);
		contentPane.add(btnRegistrar);
	}
}
