import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class ActualizarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;
	private JTextField txtDocEntra;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActualizarFuncionario frame = new ActualizarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ActualizarFuncionario() {
		setTitle("Actualizar Funcionario");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 376);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Documento:");
		label.setBounds(24, 136, 59, 14);
		contentPane.add(label);
		
		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(140, 133, 156, 20);
		contentPane.add(txtDocumento);
		
		JLabel label_1 = new JLabel("Nombres:");
		label_1.setBounds(24, 161, 46, 14);
		contentPane.add(label_1);
		
		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(139, 158, 266, 20);
		contentPane.add(txtNombres);
		
		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setBounds(24, 183, 59, 14);
		contentPane.add(label_2);
		
		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(140, 180, 265, 20);
		contentPane.add(txtApellidos);
		
		JLabel label_3 = new JLabel("Celular:");
		label_3.setBounds(24, 206, 46, 14);
		contentPane.add(label_3);
		
		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(140, 203, 191, 20);
		contentPane.add(txtCelular);
		
		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setBounds(24, 231, 59, 14);
		contentPane.add(label_4);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(140, 228, 265, 20);
		contentPane.add(txtDireccion);
		
		JLabel label_5 = new JLabel("Genero:");
		label_5.setBounds(24, 256, 46, 14);
		contentPane.add(label_5);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"M", "F", "Otro"}));
		comboBox.setBounds(140, 253, 70, 20);
		contentPane.add(comboBox);
		
		JLabel lblActualizarFuncionario = new JLabel("ACTUALIZAR FUNCIONARIO");
		lblActualizarFuncionario.setForeground(Color.RED);
		lblActualizarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblActualizarFuncionario.setBounds(106, 11, 272, 45);
		contentPane.add(lblActualizarFuncionario);
		
		JLabel label_6 = new JLabel("Documento:");
		label_6.setBounds(104, 60, 79, 14);
		contentPane.add(label_6);
		
		txtDocEntra = new JTextField();
		txtDocEntra.setColumns(10);
		txtDocEntra.setBounds(187, 57, 144, 20);
		contentPane.add(txtDocEntra);
		
		JButton button = new JButton("Consultar");
		button.setBounds(187, 83, 79, 23);
		contentPane.add(button);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.setBounds(177, 303, 89, 23);
		contentPane.add(btnActualizar);
	}

}
