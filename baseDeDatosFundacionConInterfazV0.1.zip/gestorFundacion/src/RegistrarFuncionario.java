import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class RegistrarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrarFuncionario frame = new RegistrarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistrarFuncionario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 356);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistrarFuncionario = new JLabel("REGISTRAR FUNCIONARIO");
		lblRegistrarFuncionario.setForeground(Color.RED);
		lblRegistrarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarFuncionario.setBounds(78, 26, 243, 45);
		contentPane.add(lblRegistrarFuncionario);
		
		JLabel label = new JLabel("Documento:");
		label.setBounds(43, 85, 59, 14);
		contentPane.add(label);
		
		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(159, 82, 156, 20);
		contentPane.add(txtDocumento);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(169, 266, 89, 23);
		contentPane.add(btnRegistrar);
		
		JLabel label_1 = new JLabel("Nombres:");
		label_1.setBounds(43, 110, 46, 14);
		contentPane.add(label_1);
		
		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(158, 107, 266, 20);
		contentPane.add(txtNombres);
		
		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setBounds(43, 132, 59, 14);
		contentPane.add(label_2);
		
		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(159, 129, 265, 20);
		contentPane.add(txtApellidos);
		
		JLabel label_3 = new JLabel("Celular:");
		label_3.setBounds(43, 155, 46, 14);
		contentPane.add(label_3);
		
		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(159, 152, 191, 20);
		contentPane.add(txtCelular);
		
		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setBounds(43, 180, 59, 14);
		contentPane.add(label_4);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(159, 177, 265, 20);
		contentPane.add(txtDireccion);
		
		JLabel label_5 = new JLabel("Genero:");
		label_5.setBounds(43, 205, 46, 14);
		contentPane.add(label_5);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"M", "F", "Otro"}));
		comboBox.setBounds(159, 202, 70, 20);
		contentPane.add(comboBox);
	}
}
