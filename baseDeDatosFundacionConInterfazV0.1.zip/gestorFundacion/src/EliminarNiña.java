import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;

public class EliminarNiña extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JLabel lblEliminarNia;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarNiña frame = new EliminarNiña();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EliminarNiña() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDocumento = new JLabel("Documento:");
		lblDocumento.setBounds(100, 131, 79, 14);
		contentPane.add(lblDocumento);
		
		txtDocumento = new JTextField();
		txtDocumento.setBounds(189, 128, 144, 20);
		contentPane.add(txtDocumento);
		txtDocumento.setColumns(10);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(157, 170, 89, 23);
		contentPane.add(btnEliminar);
		
		lblEliminarNia = new JLabel("ELIMINAR NI\u00D1A");
		lblEliminarNia.setForeground(Color.RED);
		lblEliminarNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblEliminarNia.setBounds(119, 24, 198, 45);
		contentPane.add(lblEliminarNia);
	}

}
