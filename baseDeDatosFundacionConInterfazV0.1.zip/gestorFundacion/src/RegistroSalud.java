import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;

public class RegistroSalud extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtFechaReg;
	private JTextField txtPeso;
	private JTextField txtAltura;
	private JTextField txtTension;
	private JTextField txtDescripcion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroSalud frame = new RegistroSalud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistroSalud() {
		setTitle("Registro de Salud Ni\u00F1a");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistroSaludNia = new JLabel("REGISTRO SALUD NI\u00D1A");
		lblRegistroSaludNia.setForeground(Color.RED);
		lblRegistroSaludNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistroSaludNia.setBounds(102, 11, 242, 45);
		contentPane.add(lblRegistroSaludNia);
		
		JLabel lblNiadocumento = new JLabel("Ni\u00F1a Documento:");
		lblNiadocumento.setBounds(10, 85, 92, 14);
		contentPane.add(lblNiadocumento);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(112, 82, 156, 20);
		contentPane.add(textField);
		
		JLabel lblFechaDeRegistro = new JLabel("Fecha de Registro:");
		lblFechaDeRegistro.setBounds(10, 109, 117, 14);
		contentPane.add(lblFechaDeRegistro);
		
		txtFechaReg = new JTextField();
		txtFechaReg.setColumns(10);
		txtFechaReg.setBounds(111, 107, 265, 17);
		contentPane.add(txtFechaReg);
		
		JLabel lblNewLabel = new JLabel("Peso:");
		lblNewLabel.setBounds(10, 134, 46, 14);
		contentPane.add(lblNewLabel);
		
		txtPeso = new JTextField();
		txtPeso.setBounds(110, 134, 86, 20);
		contentPane.add(txtPeso);
		txtPeso.setColumns(10);
		
		JLabel lblAltura = new JLabel("Altura:");
		lblAltura.setBounds(10, 163, 46, 14);
		contentPane.add(lblAltura);
		
		txtAltura = new JTextField();
		txtAltura.setBounds(110, 160, 86, 20);
		contentPane.add(txtAltura);
		txtAltura.setColumns(10);
		
		JLabel lblTension = new JLabel("Tension:");
		lblTension.setBounds(10, 194, 46, 14);
		contentPane.add(lblTension);
		
		txtTension = new JTextField();
		txtTension.setBounds(110, 191, 86, 20);
		contentPane.add(txtTension);
		txtTension.setColumns(10);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n:");
		lblDescripcin.setBounds(10, 219, 69, 14);
		contentPane.add(lblDescripcin);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(110, 216, 314, 73);
		contentPane.add(txtDescripcion);
		txtDescripcion.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setBounds(179, 300, 89, 23);
		contentPane.add(btnRegistrar);
	}

}
