//42 path=Fundacion/src/ConsultarNiña.java
